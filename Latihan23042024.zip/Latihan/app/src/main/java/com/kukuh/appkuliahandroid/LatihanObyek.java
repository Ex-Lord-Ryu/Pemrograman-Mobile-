package com.kukuh.appkuliahandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LatihanObyek extends AppCompatActivity {
    ImageButton imgbutton1;
    RadioGroup rg;
    RadioButton rb_1,rb_2;
    ToggleButton tgglbutton;
    Button btnopenactivity2; //untuk membuka activiy lain

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_latihan_obyek);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imgbutton1 = findViewById(R.id.imgbutton1);
        rg = findViewById(R.id.rg);
        rb_1 = findViewById(R.id.rb_1);
        rb_1 = findViewById(R.id.rb_1);
        tgglbutton = findViewById(R.id.tgglbutton);
        btnopenactivity2 = findViewById(R.id.btnopenactivity2);

        //---- UNTUK BUTTON OPEN
        btnopenactivity2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //perintah utk button: membuka Activity 2
                Intent latihanpage2 = new Intent(LatihanObyek.this,LatihanObyek2.class);
                startActivity(latihanpage2);
            }
        });

        //------------------- UNTUK IMAGE BUTTON
        imgbutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(LatihanObyek.this,"Selamat Datang di Unmer",
                        Toast.LENGTH_LONG).show();
            }
        });
        //-------------------------- UNTUK RADIOBUTTON
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rb_1:
                        Toast.makeText(LatihanObyek.this,"Anda Pilih Kelas Reguler",
                                Toast.LENGTH_LONG).show();
                        break;
                    case R.id.rb_2:
                        Toast.makeText(LatihanObyek.this,"Anda Pilih Kelas Sore",
                                Toast.LENGTH_LONG).show();
                        break;
                }
            }
        });
        //-------------------------- end of RADIOBUTTON

        //--------------------- TOGGLE BUTTON
        tgglbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tgglbutton.isChecked()){
                    Toast.makeText(LatihanObyek.this,"Aktif",
                            Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(LatihanObyek.this,"Tidak Aktif",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}