package com.kukuh.appkuliahandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LatihanObyek2 extends AppCompatActivity {
    //TAMBAHKAN OBYEK BUTTON dari button yang ada di XML actvty 2
    Button btnopenactivity1; //untuk membuka activiy lain
    Button btnsubmit;
    EditText edit_nama, edit_umur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_latihan_obyek2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // ... findviewbyID button tsb
        //....
        btnopenactivity1 = findViewById(R.id.btnopenactivity1);
        btnsubmit = findViewById(R.id.btnsubmit);
        edit_nama  = findViewById(R.id.edit_nama);
        edit_umur  = findViewById(R.id.edit_umur);

        //buat SetOnClickListener dr button tsb
        //...
        btnopenactivity1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //perintah utk button: membuka Activity 2
                Intent latihanpage1 = new Intent(LatihanObyek2.this,LatihanObyek.class);
                startActivity(latihanpage1);
            }
        });

        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                  //perintah utk button: membuka Activity 3
                String strnama = edit_nama.getText().toString().trim();
                String strumur = edit_umur.getText().toString().trim();
                //CEK ISI SEMUA EDIT TEXT
                if(strnama.equals("")||strumur.equals("")){
                    Toast.makeText(LatihanObyek2.this,"ISI SEMUA FIELD",
                            Toast.LENGTH_SHORT).show();
                } else {
                    //JIKA SUDAH TERISI SEMUA, MAKA
                    Intent latihanpage3 = new Intent(LatihanObyek2.this,LatihanObyek3.class);
                    latihanpage3.putExtra("nama",strnama);
                    latihanpage3.putExtra("umur",strumur);
                    startActivity(latihanpage3);
                    Toast.makeText(LatihanObyek2.this,"NAMA: "+strnama + "\nUMUR: " + strumur,
                            Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}