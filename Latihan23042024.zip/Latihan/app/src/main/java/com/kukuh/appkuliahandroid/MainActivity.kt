package com.kukuh.appkuliahandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity(), View.OnClickListener {
    lateinit var btntambah : Button
    lateinit var btnkurang : Button
    lateinit var btnkali : Button
    lateinit var btnbagi : Button
    lateinit var btnkosong : Button
    lateinit var et_a : EditText
    lateinit var et_b : EditText
    lateinit var tvHasil : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //inisiasi obyek ke variabel yg telah dideklarasikan
        btntambah = findViewById(R.id.btntambah)
        btnkurang = findViewById(R.id.btnkurang)
        btnkali = findViewById(R.id.btnkali)
        btnbagi = findViewById(R.id.btnbagi)
        btnkosong = findViewById(R.id.btnkosong)
        et_a = findViewById(R.id.et_a)
        et_b = findViewById(R.id.et_b)
        tvHasil = findViewById(R.id.tvHasil)

        btntambah.setOnClickListener(this)
        btnkurang.setOnClickListener(this)
        btnkali.setOnClickListener(this)
        btnbagi.setOnClickListener(this)
        btnkosong.setOnClickListener(this)

    }

    override fun onClick(v: View?) {
        //TODO("Not yet implemented")
        /*Variabel untuk simpan input A dan B,
        konversi ke Double agar dapat dikalkulasi
        nilai yang diinputkan disimpan di var*/
        var a = et_a.text.toString().toDouble()
        var b = et_b.text.toString().toDouble()

        //Beri nilai awal variabel hasil untuk simpan nilai operasi
        var hasil=0.0
        //cek button mana yang diklik
        when(v?.id){
            R.id.btntambah ->{
                hasil = a+b
            }
            R.id.btnkurang ->{
                hasil = a-b
            }
            R.id.btnkali ->{
                hasil = a*b
            }
            R.id.btnbagi ->{
                hasil = a/b
            }
            R.id.btnkosong ->{
                et_a.text.clear()
                et_b.text.clear()
                hasil=0.0
                et_a.requestFocus()
            }
        }

        tvHasil.text= "Hasil = $hasil"

    }


}